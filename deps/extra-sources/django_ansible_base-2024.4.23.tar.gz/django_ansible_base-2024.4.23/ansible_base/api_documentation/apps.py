from django.apps import AppConfig


class ApiDocumentationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ansible_base.api_documentation'
    label = 'dab_api_documentation'
