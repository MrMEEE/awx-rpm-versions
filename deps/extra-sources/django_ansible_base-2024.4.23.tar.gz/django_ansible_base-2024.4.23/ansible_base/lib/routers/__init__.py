from .association_resource_router import AssociationResourceRouter

__all__ = ('AssociationResourceRouter',)
