# Serializers

django-ansible-base can house common serializer fields. These are in `ansible_base.serializers.fields`.

`ansible_base.serializers.fields.URLField` can handle doing URL validation (see validation.md).
