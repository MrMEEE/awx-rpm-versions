# django-ansible-base

## What is it?
Django-ansible-base is exactly what it says it is. A base for any Ansible application which will leverage Django.

## Documentation
Docs can be found in the docs directory.
