from ansible_base.activitystream.signals import no_activity_stream

__all__ = ['no_activity_stream']
