import sys  # noqa: F401

from nothing import this_does_not_exist  # noqa: F401
