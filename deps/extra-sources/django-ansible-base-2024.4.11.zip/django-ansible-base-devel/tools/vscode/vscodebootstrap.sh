python manage.py migrate
python manage.py create_demo_data
